//
//  ViewController.swift
//  DiscountAppMVC
//
//  Created by Kutikanti,Supriya on 11/2/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var Enteramount: UILabel!
    
    
    @IBOutlet weak var enterdiscount: UILabel!
    
    
    @IBOutlet weak var amounttext: UITextField!
    
    
    @IBOutlet weak var discounttext: UITextField!
    
    
    
    @IBOutlet weak var calculatebutton: UIButton!
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    if let heightText = heightTextField.text 


}

