//
//  ViewController.swift
//  bmiMVC
//
//  Created by Kutikanti,Supriya on 11/2/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

